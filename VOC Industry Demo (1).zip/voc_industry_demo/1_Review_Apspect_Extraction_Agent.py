# Databricks notebook source
# MAGIC %md
# MAGIC # 1. Agent bricks: Review Apspect Extraction Agent
# MAGIC
# MAGIC This notebook walks through instructions to build an Information Extraction Agent in Agent Bricks to extract aspect insights & sentiments from raw reviews
# MAGIC
# MAGIC Data Flow: 
# MAGIC **raw reviews -> review aspect extractions**  -> location aspect daily -> flag all issues -> issue diagnosis and recommendations

# COMMAND ----------

# MAGIC %md
# MAGIC ## Build Information Extraction Agent
# MAGIC
# MAGIC Extract Structured Insights from Raw Reviews
# MAGIC
# MAGIC Example: 

# COMMAND ----------

# MAGIC %md
# MAGIC - Information Extraction Agent: Schema Config [`ie_agent_config.json`](/Workspace/Users/cindy.wu@databricks.com/voc_industry_demo/ie_agent_config.json)
# MAGIC - Instructions: 
# MAGIC
# MAGIC ```
# MAGIC 1. Extract ALL relevant metadata mentioned or implied in the review.
# MAGIC    - Include fields such as: star rating, review date, length of stay, and overall sentiment.
# MAGIC    - If metadata is missing, set to null — do not guess or invent.
# MAGIC
# MAGIC 2. Extract EVERY relevant aspect from the review text.
# MAGIC    - Use the predefined aspect list (Arrival & Departure, Staff & Service, In-Room Experience, Food & Beverage, Facilities & Amenities, Environment & Location, Value & Loyalty).
# MAGIC    - For each aspect:
# MAGIC        • Identify sentiment (very_positive, positive, neutral, negative, very_negative).
# MAGIC        • Include short, verbatim evidence (phrases directly from the review).
# MAGIC        • opinion_terms: array of short polarity-bearing words/phrases tied to this aspect (e.g., “spotless,” “friendly,” “overpriced,” “noisy AC”); use verbatim spans when possible
# MAGIC    - Deduplicate aspects — each aspect should appear at most once.
# MAGIC    - Do not miss subtle mentions, mixed opinions, or multiple details for the same aspect.
# MAGIC    - Capture both positive and negative details accurately, without omitting context.
# MAGIC
# MAGIC 3. Extract all **entities** explicitly or implicitly mentioned in the review.
# MAGIC    - Entities include: staff roles or names, attractions, nearby locations etc.
# MAGIC    - Keep entity names consistent and distinct.
# MAGIC    - Do not fabricate entities; if unclear, set to null.
# MAGIC    - Avoid redundancy: each unique entity should appear only once.
# MAGIC
# MAGIC 4. Output clean, valid JSON following the specified schema (no extra text, no commentary).
# MAGIC    - Ensure consistency across reviews.
# MAGIC    ```

# COMMAND ----------

# MAGIC %md
# MAGIC ## Batch Inference With IE Agent Endpoint and `AI_QUERY`
# MAGIC #### [IE Query in SQL Editor](/Workspace/Users/cindy.wu@databricks.com/voc_industry_demo/queries/AI Query Extraction with KIE.dbquery.ipynb)
# MAGIC

# COMMAND ----------

# DBTITLE 1,Batch Inference
# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE lakehouse_inn_catalog.voc.review_extractions AS
# MAGIC WITH query_results AS (
# MAGIC   SELECT
# MAGIC     review_id,
# MAGIC     review_text,
# MAGIC     ai_query(
# MAGIC       'kie-b59e4876-endpoint',
# MAGIC       review_text,
# MAGIC       failOnError => false
# MAGIC     ) AS respon
# MAGIC     
# MAGIC     se
# MAGIC   FROM (
# MAGIC     SELECT review_id, review_text
# MAGIC     FROM lakehouse_inn_catalog.voc.raw_reviews
# MAGIC   )
# MAGIC )
# MAGIC SELECT
# MAGIC   review_id,
# MAGIC   review_text,
# MAGIC   response.result AS response,
# MAGIC   response.errorMessage AS error
# MAGIC FROM query_results;
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## MAS Agent with KA and Genie Room

# COMMAND ----------

# MAGIC %md
# MAGIC 0. data generation
# MAGIC - generate raw review data with ai_query based on list of locations and channels
# MAGIC - generate hotel runbook based on list of aspects
# MAGIC - [Lakebase] Sync Hotel runbook to lakebase
# MAGIC
# MAGIC 1. Extract Insights
# MAGIC - [Agent Bricks, SQL] Build Infmroation Extraction Agent and AI_QUERY to extract insights from raw review 
# MAGIC
# MAGIC 2. Diagnosis
# MAGIC - [Notebook] Aggreate insights by location-aspect and calcualte metrics
# MAGIC - [Notebook] Create issues table based on extracted location-aspect metrics
# MAGIC - [Lakebass] Sync latest issues table to lakebase
# MAGIC - [Agent Bricks] Use Custom LLM to idenitify issue causes based on relevant reviews and provide summary
# MAGIC - [Lakebase, Apps] Sync issues table to lakebase
# MAGIC - [AI/BI] Build Genie room for raw reviews and issues table for deep dive
# MAGIC - [AI/BI, Apps] Build dashboard to visualize issues by location, map view
# MAGIC
# MAGIC 3. Recommendations
# MAGIC - [Notebook] Generate emails based on issue and hotel runbook in App
# MAGIC - [Agent Bricks, Apps] Build MAS with Genie and KA 
# MAGIC

# COMMAND ----------



# COMMAND ----------

from pyspark.sql import functions as F, Window as W
diag = "lakehouse_inn_catalog.voc.open_issues_diagnosis"

# Load issues table
issues_df = spark.table(diag)

# Window to get the latest opened_at per (aspect, location)
w = W.partitionBy("aspect", "location").orderBy(F.col("opened_at").desc())

# Add row number to identify the latest issue per group
issues_ranked = issues_df.withColumn("rn", F.row_number().over(w))

# Create new status column: only the latest as Open, others as Closed
issues_final = (
    issues_ranked.withColumn(
        "status",
        F.when(F.col("rn") == 1, F.lit("Open")).otherwise(F.lit("Closed"))
    )
    .drop("rn")
)

# Overwrite the table with the updated status column
issues_final.write.format("delta").mode("overwrite").option("overwriteSchema", "true").saveAsTable(diag)