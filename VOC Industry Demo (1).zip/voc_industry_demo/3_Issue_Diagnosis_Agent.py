# Databricks notebook source
# MAGIC %md
# MAGIC # 3. Issue Dianosis: Agent Bricks Custom LLM
# MAGIC
# MAGIC Data Flow: raw reviews -> review aspect extractions -> location aspect daily -> flag all issues -> **issue diagnosis and recommendations**
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Build Custom LLM Agent (Summary + Diagnosis)

# COMMAND ----------

# MAGIC %md
# MAGIC - Instructions: 
# MAGIC ```
# MAGIC You are an experienced hotel operations analyst.
# MAGIC Given a single issue aspect (for example, “cleanliness” or “temperature_hvac”) and several short review extracts related to that issue, write a concise and factual diagnosis summarizing what the data indicates.
# MAGIC
# MAGIC Rules:
# MAGIC 	1.	Base everything strictly on the provided reviews. Identify common complaints and patterns across guests.
# MAGIC 	2.	Do not make up facts — only infer root causes that clearly align with evidence.
# MAGIC 	3.	Keep tone factual, professional, and concise.
# MAGIC 	4.	Summarize in the following four parts only:
# MAGIC 		• issue_summary → what the guests are saying (pattern)
# MAGIC 		• potential_root_cause → why it’s likely happening
# MAGIC 		• impact → how it affects guest experience or brand
# MAGIC 		• recommended_action → clear, actionable steps to fix or prevent recurrence
# MAGIC 	5.	The output must be valid JSON. No markdown, no additional commentary.
# MAGIC 	6.	Keep total text per field under ~3 sentences.
# MAGIC
# MAGIC Output format:
# MAGIC {
# MAGIC   "aspect": "<aspect_name>",
# MAGIC   "issue_summary": "<short summary of the pattern in guest reviews>",
# MAGIC   "potential_root_cause": "<likely operational or maintenance causes>",
# MAGIC   "impact": "<how it affects guest satisfaction, comfort, or reputation>",
# MAGIC   "recommended_action": "<specific and practical steps to address the issue>"
# MAGIC }
# MAGIC ```

# COMMAND ----------

# MAGIC %md
# MAGIC ## Batch Inference With CLLM Agent Endpoint and `AI_QUERY`
# MAGIC [CLLM Query in SQL Editor](/Workspace/Users/cindy.wu@databricks.com/voc_industry_demo/queries/AI Query with CLLM Diagnosis.dbquery.ipynb)

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE lakehouse_inn_catalog.voc.open_issues_diagnosis AS
# MAGIC WITH query_results AS (
# MAGIC   SELECT
# MAGIC     *,
# MAGIC     ai_query(
# MAGIC       't2t-e71a8879-endpoint',
# MAGIC       relevant_reviews_text,
# MAGIC       failOnError => false
# MAGIC     ) AS response
# MAGIC   FROM (
# MAGIC     SELECT *
# MAGIC     FROM lakehouse_inn_catalog.voc.issues_daily
# MAGIC     -- WHERE status = 'Open'
# MAGIC   )
# MAGIC )
# MAGIC SELECT
# MAGIC   -- Exclude the response column
# MAGIC   issue_id,
# MAGIC   opened_at,
# MAGIC   location,
# MAGIC   aspect,
# MAGIC   severity,
# MAGIC   status,
# MAGIC   open_reason,
# MAGIC   delta_pp_open,
# MAGIC   nms_open,
# MAGIC   volume_open,
# MAGIC   relevant_reviews,
# MAGIC   response.result AS response_result,
# MAGIC   response.errorMessage AS response_error,
# MAGIC   current_date() AS processed_date
# MAGIC FROM query_results;
# MAGIC
# MAGIC

# COMMAND ----------

display(spark.table('lakehouse_inn_catalog.voc.open_issues_diagnosis'))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Next Step: AI/BI Dashboard & Genie Room

# COMMAND ----------

# MAGIC %md
# MAGIC ## MAS Agent with KA and Genie Room

# COMMAND ----------

# MAGIC %md
# MAGIC 0. data generation
# MAGIC - generate raw review data with ai_query based on list of locations and channels
# MAGIC - generate hotel runbook based on list of aspects
# MAGIC - [Lakebase] Sync Hotel runbook to lakebase
# MAGIC
# MAGIC 1. Extract Insights
# MAGIC - [Agent Bricks, SQL] Build Infmroation Extraction Agent and AI_QUERY to extract insights from raw review 
# MAGIC
# MAGIC 2. Diagnosis
# MAGIC - [Notebook] Aggreate insights by location-aspect and calcualte metrics
# MAGIC - [Notebook] Create issues table based on extracted location-aspect metrics
# MAGIC - [Lakebass] Sync latest issues table to lakebase
# MAGIC - [Agent Bricks] Use Custom LLM to idenitify issue causes based on relevant reviews and provide summary
# MAGIC - [Lakebase, Apps] Sync issues table to lakebase
# MAGIC - [AI/BI] Build Genie room for raw reviews and issues table for deep dive
# MAGIC - [AI/BI, Apps] Build dashboard to visualize issues by location, map view
# MAGIC
# MAGIC 3. Recommendations
# MAGIC - [Notebook] Generate emails based on issue and hotel runbook in App
# MAGIC - [Agent Bricks, Apps] Build MAS with Genie and KA 
# MAGIC

# COMMAND ----------



# COMMAND ----------

from pyspark.sql import functions as F, Window as W
diag = "lakehouse_inn_catalog.voc.open_issues_diagnosis"

# Load issues table
issues_df = spark.table(diag)

# Window to get the latest opened_at per (aspect, location)
w = W.partitionBy("aspect", "location").orderBy(F.col("opened_at").desc())

# Add row number to identify the latest issue per group
issues_ranked = issues_df.withColumn("rn", F.row_number().over(w))

# Create new status column: only the latest as Open, others as Closed
issues_final = (
    issues_ranked.withColumn(
        "status",
        F.when(F.col("rn") == 1, F.lit("Open")).otherwise(F.lit("Closed"))
    )
    .drop("rn")
)

# Overwrite the table with the updated status column
issues_final.write.format("delta").mode("overwrite").option("overwriteSchema", "true").saveAsTable(diag)