# Databricks notebook source
# MAGIC %md
# MAGIC # 4. AI/BI Dashboard & Genie Room
# MAGIC
# MAGIC Build Overview Dashboard and Property Dashboard using json configs
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Overview Dashboard
# MAGIC - [Overview Dashboard Config](/Workspace/Users/cindy.wu@databricks.com/voc_industry_demo/resource_configs/Lakehouse Inn VoC Overview Dashboard.json)
# MAGIC ![](/Workspace/Users/cindy.wu@databricks.com/voc_industry_demo/images/overview_dashboard_screenshot.png)
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Property Dashboard
# MAGIC - [Property Dashboard Config](/Workspace/Users/cindy.wu@databricks.com/voc_industry_demo/resource_configs/Lakehouse Inn VoC Property Dashboard.json)
# MAGIC ![](/Workspace/Users/cindy.wu@databricks.com/voc_industry_demo/images/property_dashboard_screenshot.png)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Genie Room
# MAGIC
# MAGIC 1. Add Data Sources
# MAGIC - lakehouse_inn_catalog.voc.review_aspect_details
# MAGIC - lakehouse_inn_catalog.voc.issues_daily
# MAGIC
# MAGIC 2. Add Descriptions
# MAGIC > ```
# MAGIC > This data room contains reivews about Lakehouse Inn
# MAGIC > 
# MAGIC > Available Data:
# MAGIC > - lakehouse_inn_catalog.voc.raw_reviews:  Hotel guest reviews from various channels and locations. Each row is one review.
# MAGIC > 
# MAGIC > - lakehouse_inn_catalog.voc.review_extractions: Raw JSON output from ai_query extractions containing structured review insights (aspects, entities, metadata, sentiment).
# MAGIC > 
# MAGIC > - lakehouse_inn_catalog.voc.issues_daily: Detected open issues representing statistically significant negative trends per aspect/location/day. Includes metadata, severity, and relevant reviews.
# MAGIC > ```
# MAGIC
# MAGIC 3. (Optional) Add Insturctions
# MAGIC
# MAGIC

# COMMAND ----------

