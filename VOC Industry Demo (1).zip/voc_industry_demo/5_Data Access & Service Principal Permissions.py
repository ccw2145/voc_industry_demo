# Databricks notebook source
# MAGIC %md
# MAGIC #### Permissions
# MAGIC - Need to give group privilieges to schema. User is group name not user name.
# MAGIC `user = "voc-demo"`
# MAGIC - In Groups entitlement, grant Group entitlement for Workspace (default to not)
# MAGIC - Need to grant permissions to SP for SQL endpoint
# MAGIC
# MAGIC
# MAGIC - Permissions to UC to All SP
# MAGIC - Permission to Compute clusters (sql)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Set up Service Principal & Row level filter

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Step 1: Create the mapping table
# MAGIC CREATE OR REPLACE TABLE lakehouse_inn_catalog.voc.sp_location_acl (
# MAGIC   service_principal_name STRING,
# MAGIC   service_principal_id STRING,
# MAGIC   allowed_location STRING
# MAGIC );
# MAGIC --  TODO: replace sample service principals and users
# MAGIC INSERT INTO lakehouse_inn_catalog.voc.sp_location_acl VALUES
# MAGIC   ('boston-demo-sp', 'c29e43e6-d791-4314-bdea-87440b7e0212', 'Boston, MA'),
# MAGIC   ('seattle-demo-sp','', 'Seattle, WA'),
# MAGIC   ('austin-demo-sp', '','Austin, TX');
# MAGIC
# MAGIC -- Step 2: Create the row filter function
# MAGIC --  TODO: replace with acutal users
# MAGIC
# MAGIC CREATE OR REPLACE FUNCTION lakehouse_inn_catalog.voc.location_acl_filter(
# MAGIC   location STRING
# MAGIC )
# MAGIC RETURNS BOOLEAN
# MAGIC RETURN
# MAGIC   current_user() IN ('cindy.wu@databricks.com', 'robert.mosley@databricks.com', 'dan.morris@databricks.com', 'krishna.r@databricks.com
# MAGIC ', 'bdae5339-4ad3-4c8d-b45d-02d2134752b8', '4bba4b51-48c5-4331-964b-db6c6a35f06e')
# MAGIC   OR EXISTS (
# MAGIC     SELECT 1
# MAGIC     FROM lakehouse_inn_catalog.voc.sp_location_acl
# MAGIC     WHERE service_principal_id = current_user()
# MAGIC       AND allowed_location = location
# MAGIC   )
# MAGIC ;

# COMMAND ----------

# MAGIC %sql
# MAGIC ALTER TABLE lakehouse_inn_catalog.voc.issues_daily
# MAGIC SET ROW FILTER lakehouse_inn_catalog.voc.location_acl_filter ON (location);

# COMMAND ----------

# MAGIC %sql
# MAGIC ALTER TABLE lakehouse_inn_catalog.voc.raw_reviews
# MAGIC SET ROW FILTER lakehouse_inn_catalog.voc.location_acl_filter ON (location);

# COMMAND ----------

# MAGIC %sql
# MAGIC ALTER TABLE lakehouse_inn_catalog.voc.review_aspect_details
# MAGIC SET ROW FILTER lakehouse_inn_catalog.voc.location_acl_filter ON (location);

# COMMAND ----------

# MAGIC %md
# MAGIC ## Test out row filters

# COMMAND ----------

# MAGIC %pip install databricks-sql-connector
# MAGIC %restart_python
# MAGIC

# COMMAND ----------

import os
os.environ["SP_DATABRICKS_CLIENT_SECRET"] ='dosea606bbdbc84d69321a1edd472dc3ee15'
os.environ["SP_DATABRICKS_CLIENT_ID"] ='c29e43e6-d791-4314-bdea-87440b7e0212'
os.environ["DATABRICKS_HTTP_PATH"] = "/sql/1.0/warehouses/a9fea331792bc9d6"
os.environ["DATABRICKS_SERVER_HOSTNAME"] = 'fe-vm-voc-lakehouse-inn-workspace.cloud.databricks.com'

# COMMAND ----------

# DBTITLE 1,Test SP ACL
from databricks import sql
from databricks.sdk.core import Config

from databricks.sdk.core import Config, oauth_service_principal
from databricks import sql
import os

server_hostname = os.getenv("DATABRICKS_SERVER_HOSTNAME")
def credential_provider():
  config = Config(
    host          = f"https://{server_hostname}",
    client_id=os.getenv("SP_DATABRICKS_CLIENT_ID"),
    client_secret=os.getenv("SP_DATABRICKS_CLIENT_SECRET"))
  return oauth_service_principal(config)

with sql.connect(server_hostname      = server_hostname,
                 http_path            = os.getenv("DATABRICKS_HTTP_PATH"),
                 credentials_provider = credential_provider) as conn:
    query = "SELECT * FROM lakehouse_inn_catalog.voc.issues_daily"
    # query = "SELECT * FROM lakehouse_inn_catalog.voc.review_aspect_details"

    # query = "SELECT current_user();"
    with conn.cursor() as cursor:
        cursor.execute(query)
        df = cursor.fetchall_arrow().to_pandas()
        print(df.head())
    conn.close()

# COMMAND ----------

# MAGIC %md
# MAGIC ## (Optional or UI) Sync runbook table to Lakebase (for app performance)
# MAGIC

# COMMAND ----------

# from databricks.sdk import WorkspaceClient
# from databricks.sdk import WorkspaceClient
# from databricks.sdk.service.database import SyncedDatabaseTable, SyncedTableSpec, NewPipelineSpec, SyncedTableSchedulingPolicy
# # Initialize the Workspace client
# w = WorkspaceClient()

# # Create a synced table in a database catalog
# synced_table = w.database.create_synced_database_table(
#     SyncedDatabaseTable(
#         name="database_catalog.schema.synced_table",  # Full three-part name
#         spec=SyncedTableSpec(
#             source_table_full_name="source_catalog.source_schema.source_table",
#             primary_key_columns=["id"],  # Primary key columns
#             scheduling_policy=SyncedTableSchedulingPolicy.TRIGGERED,  # SNAPSHOT, TRIGGERED, or CONTINUOUS
#             # Optional: timeseries_key="timestamp"  # For deduplication
#             new_pipeline_spec=NewPipelineSpec(
#                 storage_catalog="storage_catalog",
#                 storage_schema="storage_schema"
#             )
#         ),
#     )
# )
# print(f"Created synced table: {synced_table.name}")


# COMMAND ----------

